export class productModel {
    constructor(public productImage: string, 
                public productName: string, 
                public productDescription : string[],
                public productDescImage: string,
                public productDescDetail: string[]) {}
}